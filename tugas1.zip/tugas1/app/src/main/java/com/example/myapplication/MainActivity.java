package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btn_kubus;
    private Button btn_tabung;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_kubus = findViewById(R.id.kubus);
        btn_tabung = findViewById(R.id.tabung);

        btn_kubus.setOnClickListener(new View.OnClickListener()

                                     {
                                         public void onClick(View k){
                                             Intent moveIntent = new Intent(MainActivity.this,volumekubus.class);
                                             startActivity(moveIntent);
                                         }
                                     }
        );

        btn_tabung.setOnClickListener(new View.OnClickListener()
                                      {
                                          public void onClick(View k){
                                              Intent moveIntent = new Intent(MainActivity.this,volumetabung.class);
                                              startActivity(moveIntent);
                                          }
                                      }
        );

    }
}
