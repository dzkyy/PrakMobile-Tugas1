package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class volumekubus extends AppCompatActivity {

    private Button vKubus;
    private EditText etSisi;
    private TextView kHasil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volumekubus);

        vKubus = findViewById(R.id.v_kubus);
        etSisi = findViewById(R.id.sisi);
        kHasil = findViewById(R.id.k_hasil);

        vKubus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String sSisi = etSisi.getText().toString();

                Double sisi = Double.parseDouble(sSisi);

                double hasil = sisi*sisi;

                String sHasil = String.valueOf(hasil);
                kHasil.setText(sHasil);
            }
        });

    }
}
