package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class volumetabung extends AppCompatActivity {

    private Button vTabung;
    private EditText etPhi;
    private EditText etJari;
    private TextView tHasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volumetabung);

        vTabung = findViewById(R.id.v_tabung);
        etJari = findViewById(R.id.jari);
        tHasil = findViewById(R.id.t_hasil);

        vTabung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String sJari = etJari.getText().toString();

                Double jari = Double.parseDouble(sJari);

                double hasil = 3.14*jari*jari;

                String sHasil = String.valueOf(hasil);
                tHasil.setText(sHasil);
            }
        });

    }
}
